package com.project.zzimccong.security.service.corp;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface CorpDetailService extends UserDetailsService {
    // 필요한 경우 추가 메서드 선언
}
