package com.project.zzimccong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZzimccongApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZzimccongApplication.class, args);
	}

}
