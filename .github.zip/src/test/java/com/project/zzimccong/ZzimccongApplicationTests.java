package com.project.zzimccong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZzimccongApplicationTests {

	@Test
	void contextLoads() {
	}

}
